<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Long Acting Contraception</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
		<!-- Style sheets -->
		<link rel="stylesheet" href="../../css/main.css">
		<!-- Utilities -->
		<script src="../../js/vendor/modernizr.min.js"></script>
	</head>
<body data-lang="en_us" data-version="1">

	<!-- Lightbox -->
	<div class="fancybox-reveal-content">
		<div class="modal-header">
			<b class="headline" id="head-title">Privacy Statement</b>
		</div>
		<div class="modal-body">
			<div class="scroll-content">
				<div class="col-12">
					<p>We take the protection of your personal data very seriously. Therefore we would like you to know what data we maintain and what data we discard. With this privacy statement, we would like to inform you about our security measures.</p>

					<p><b>Collection of Data</b></p>
					<p>When you use our website, data may be stored for various security purposes. This data may include the name of your Internet service provider, the website that you used to link to our site, the web sites that you visit from our site and your IP address. This data could possibly lead to your identification, but we do not use it to do so. We do use the data from time to time for statistical purposes, but maintain the anonymity of each individual user so that the person cannot be identified. In cases when personal data is provided to others to provide you products or services you have requested, or for other purposes you have authorized, we rely on technical and organizational means to assure that applicable data security regulations are followed.</p>

					<p><b>Collection and processing of personal data</b></p>
					<p>We collect personal data only when you provide it to us, through registration, completion of forms or e-mails, as part of an order for products or services, inquiries or requests about materials being ordered and similar situations in which you have chosen to provide the information to us.</p>
					<p>The database and its contents remain at our company and stay with data processors or servers acting on our behalf and responsible to us. Your personal data will not be passed on by us or by our agents for use by third parties in any form whatsoever, unless we have obtained your consent or are legally required to do so.</p>
					<p>We will retain control of and responsibility for the use of any personal data you disclose to us. Some of this data may be stored or processed at computers located in other jurisdictions, such as the United States, whose data protection laws may differ from the jurisdiction in which you live. In such cases, we will ensure that appropriate protections are in place to require the data processor in that country to maintain protections on the data that are equivalent to those that apply in the country in which you live.</p>

					<p><b>Purposes of Use</b></p>
					<p>The data we collect will only be used for the purpose of supplying you with the requested products or services or for other purposes for which you have given your consent, except where otherwise provided by law</p>

					<p><b>Right of Access and Correction</b></p>
					<p>You have the right to review and amend any personal data stored in our system if you believe it may be out of date or incorrect. Just send an e-mail to the address given in the imprint or contact the Privacy Officer at the address below.</p>

					<p><b>Right of Cancellation</b></p>
					<p>You have the right at any time to withdraw your consent to the use of your personal data in the future. Again, just send an e-mail to the address given in the imprint or contact the Privacy Officer at the address below.</p>

					<p><b>Data Retention</b></p>
					<p>We only retain personal data for as long as is necessary for us to render a service you have requested or to which you have given your consent, except where otherwise provided by law (e.g. in connection with pending litigation).</p>

					<p><b>Use of Cookies</b></p>
					<p>Cookies are small text files that are stored in the visitor’s local browser cache. Using such cookies it is possible to recognize the visitor’s browser in order to optimize the website and simplify its use. Data collected via cookies will not be used to determine the personal identity of the website visitor. Most browsers are configured to accept cookies automatically. You can configure your browser to reject them, or to inform you when they are being set.</p>

					<p>Cookies used on this website</p>
					<table class="cookie-list">
						<thead>
							<tr>
								<td><b>Name</b></td>
								<td><b>Purpose</b></td>
								<td><b>Lifespan</b></td>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>Lang</td>
								<td>Store language preferences for the website</td>
								<td>30 days</td>
							</tr>
						</tbody>
					</table>

					<p><b>Security</b></p>
					<p>Bayer Pharma AG uses technical and organizational security precautions to protect your data from manipulation, loss, destruction or access by unauthorized persons. Any personal data that is provided to Bayer Pharma AG by you will be encrypted in transit to prevent its possible misuse by third parties. Our security procedures are continuously revised based on new technological developments.</p>

					<p><b>Children</b></p>
					<p>In light of the importance of protecting children’s privacy, we do not collect, process or use on our website any information relating to an individual whom we know to be under 13 years old without the prior, verifiable consent of his or her legal representative. Such legal representative has the right, upon request, to view the information provided by the child and/or to require that it be deleted.</p>

					<p><b>Contacts</b></p>
					<p>If you have any problems, questions or ideas, please contact the following persons:</p>
					<p>Data Protection Officer Bayer Pharma AG</p>

					<ul class="lists">
					    <li>Georg Schwonek</li>
					    <li>Bayer Pharma AG</li>
					    <li>Müllerstr. 178</li>
					    <li>13353 Berlin, Germany</li>
					    <li><a href="mailto:georg.schwonek@bayer.com">E-Mail</a></li>
					</ul>
					<p>Head of Data Privacy of Bayer AG</p>
					<ul class="lists">
					    <li>Eva Gardyan-Eisenlohr</li>
					    <li>Müllerstr. 178</li>
					    <li>13353 Berlin, Germany</li>
					    <li>Phone: +49 (0) 30 468 16924</li>
					    <li><a target="_blank" href="https://secure.bayer.com/bayer-group/data-privacy.aspx?lang=en">E-mail</a></li>
					</ul>
					<p>The constant development of the internet requires occasional adjustments to our privacy statement. We retain the right to make changes when necessary.</p>
				</div>
			</div>
		</div>
	</div>
	<!-- JavaScript -->
	<!--[if lt IE 10]><script src="js/vendor/media.match.min.js"></script><![endif]-->
	<script src="../../js/vendor/jquery.min.js"></script>
	<script src="../../js/vendor/enquire.min.js"></script>
	<script src="../../js/vendor/TweenMax.min.js"></script>
	<script src="../../js/vendor/jquery.mousewheel.pack.js"></script>
	<script src="../../js/vendor/jscrollpane.min.js"></script>
	<script src="../../js/app-lightbox.js"></script>
</body>
</html>