<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Long Acting Contraception</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
		<!-- Style sheets -->
		<link rel="stylesheet" href="../../css/main.css">
		<!-- Utilities -->
		<script src="../../js/vendor/modernizr.min.js"></script>
	</head>
<body data-lang="en_us" data-version="1">

	<!-- Lightbox -->
	<div class="fancybox-reveal-content">
		<div class="modal-header">
			<b class="headline" id="head-title">Imprint</b>
		</div>
		<div class="modal-body">
			<div class="scroll-content">
				<div class="col-12">
					<p><b>Supplier:</b></p>
					<p>Bayer Pharma AG</p>
                    <br/>
					<p>Board of Management:</p>
					<p>Dieter Weinand, Chairman of the Board of Management| Christoph Bertram</p>
					<p>Chairman of the Supervisory Board: Hartmut Klusik </p>
					<p>Place of Business: Berlin | Entry: County Court Charlottenburg HRB 283 B</p>
                    <br/>
					<p>13342 Berlin, Germany</p>
					<p>phone: +49-30-468-11 11</p>
					<p>for E-mail contact please click <a href="https://pharma.bayer.com/en/SSL/contact/index.php">here</a></p>
                    <br/>
					<p>Turnover tax ID no.: DE 136.563.568</p><br><br>
                    <br/>
					<p><b>Edited by:</b></p>
					<p>Bayer Pharma AG</p>
					<p>BU General Medicine</p>
					<p>13342 Berlin, Germany</p>
                    <br/>
					<p>MAP-Number: G.MKT.WH.03.2016.0169</p>
				</div>
			</div>
		</div>
	</div>
	<!-- JavaScript -->
	<!--[if lt IE 10]><script src="js/vendor/media.match.min.js"></script><![endif]-->
	<script src="../../js/vendor/jquery.min.js"></script>
	<script src="../../js/vendor/enquire.min.js"></script>
	<script src="../../js/vendor/TweenMax.min.js"></script>
	<script src="../../js/vendor/jquery.mousewheel.pack.js"></script>
	<script src="../../js/vendor/jscrollpane.min.js"></script>
	<script src="../../js/app-lightbox.js"></script>
</body>
</html>