<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Long Acting Contraception</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
		<!-- Style sheets -->
		<link rel="stylesheet" href="../../css/main.css">
		<!-- Utilities -->
		<script src="../../js/vendor/modernizr.min.js"></script>
	</head>
<body data-lang="en_us" data-version="1">

	<!-- Lightbox -->
	<div class="fancybox-reveal-content">
		<div class="modal-header">
			<b class="headline" id="head-title">Accessibility</b>
		</div>
		<div class="modal-body">
			<div class="scroll-content">
				<div class="col-12">

					<p>This website endeavours to conform to level Double-A of the World Wide Web Consortium (W3C) Web Content Accessibility Guidelines 2.0. These guidelines explain how to make web content more accessible for people with disabilities. The templates for the pages were all checked and adhered well to these guidelines.</p>
					<p>Conformance with these guidelines will help make the web more user friendly for all people. User accessibility testing was performed during the development of the site, with users with diverse access requirements using a range of assistive technologies to ensure the site was usable under multiple circumstances.</p>
					<p>This site has been built using code compliant with W3C standards for HTML and CSS. The site displays correctly in current browsers and using standards compliant HTML/CSS code means any future browsers will also display it correctly. Where any other technologies have been used they have been designed to degrade gracefully where these technologies are not present and have ensured that the navigation and workings of the site will not be affected by their absence.</p>
					<p>Throughout the design phase of the site we endeavoured to keep the needs of blind or partially sighted users at the forefront and included tools to aid access for these users. The site is compatible with screen readers and can be navigated without the use with a variety of input devices.</p>
					<p>We are making every effort to ensure that we don't exclude any users. For example:</p>
					<ul class="lists">
				    <li>We try to use language that is appropriate to the audience</li>
				    <li>We use alternative text for all our images</li>
				    <li>The HTML we produce conforms to the standard: XHTML 1.1 Strict</li>
				    <li>We always include a text transcript when we publish videos</li>
				    <li>We have tested the colours we use in the design for contrast and for use by users with multiple forms of colour blindness</li>
					</ul>
					<p>We decided not to use access keys after they caused confusion in our user testing. (The users who might have benefited from access keys already used keyboard shortcuts, and said that additional, site-specific access keys were not helpful.)</p>
				</div>
			</div>
		</div>
	</div>
	<!-- JavaScript -->
	<!--[if lt IE 10]><script src="js/vendor/media.match.min.js"></script><![endif]-->
	<script src="../../js/vendor/jquery.min.js"></script>
	<script src="../../js/vendor/enquire.min.js"></script>
	<script src="../../js/vendor/TweenMax.min.js"></script>
	<script src="../../js/vendor/jquery.mousewheel.pack.js"></script>
	<script src="../../js/vendor/jscrollpane.min.js"></script>
	<script src="../../js/app-lightbox.js"></script>
</body>
</html>