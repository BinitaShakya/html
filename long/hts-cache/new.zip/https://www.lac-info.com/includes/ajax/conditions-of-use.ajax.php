<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Long Acting Contraception</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
		<!-- Style sheets -->
		<link rel="stylesheet" href="../../css/main.css">
		<!-- Utilities -->
		<script src="../../js/vendor/modernizr.min.js"></script>
	</head>
<body data-lang="en_us" data-version="1">

	<!-- Lightbox -->
	<div class="fancybox-reveal-content">
		<div class="modal-header">
			<b class="headline" id="head-title">Conditions of use</b>
		</div>
		<div class="modal-body">
			<div class="scroll-content">
				<div class="col-12">
					<p><b>Conditions of use</b></p>
					<p>This website has been developed by the Bayer Pharma AG (hereinafter to be referred to as BAYER) and is administrated by the same. We reserve the right to discontinue or to make partial or complete modifications to this website or to the General Conditions of Use, to our General Terms and Conditions, and to our Conditions of Sale and Delivery. Please note that we may make such changes at our own discretion and without prior announcement. We must therefore ask you, next time you visit this website, to view the conditions again and to note any changes or amendments that may have been made.</p>

					<p><b>Surrender of use and benefit</b></p>
					<p>All details, documents and illustrations published on this website are the sole property of BAYER. Any permission to use the same is granted on the proviso that the relevant copyright note is displayed on all copies, that such details are only used for personal purposes, that they are not exploited commercially, that the details are not modified in any way and that all illustrations gained from the website are only used in conjunction with the accompanying text.</p>

					<p><b>Trademarks</b></p>
					<p>All product names in upper-case letters or marked in some other way on this website are trademarks of BAYER, its subsidiaries, affiliates, licensors or joint venture partners. Any unauthorized use or abuse of these trademarks or other materials is expressly prohibited and constitutes a violation of copyright, trademark law or other industrial property rights.</p>

					<p><b>Limited liability</b></p>
					<p>BAYER has compiled the detailed information provided on this website from internal and external sources to the best of its knowledge and belief, using professional diligence. We endeavor to expand and update this range of information on an ongoing basis. The information on this website is purely for the purpose of presenting BAYER and its products and services. However, no representation is made or warranty given, either expressly or tacitly, for the completeness or correctness of the information on this website. Please be aware that this information although accurate on the day it was published may no longer be up to date. We therefore recommend that you check any information you obtain from this website prior to using it in whatever form. Advice given on this website does not exempt you from conducting your own checks on our latest advice - particularly our safety datasheets and technical specifications - and on our products, with a view to their suitability for the intended processes and purposes. Should you require any advice or instructions concerning our products or services, please contact us directly. Users of this website declare that they agree to access the website and its content at their own risk. Neither BAYER nor third parties involved in the writing, production or transmission of this website can be held liable for damage or injury resulting from access or the impossibility of access or from the use or impossibility of use of this website or from the fact that you have relied on information given on this website.</p>

					<p><b>Websites of third-party vendors/links</b></p>
					<p>This website contains links/references to third-party websites. By providing such links, BAYER does not give its approval to their contents. Neither does BAYER accept any responsibility for the availability or the contents of such websites or any liability for damage or injury resulting from the use of such contents, of whatever form. BAYER offers no guarantee that pages linked to provide information of consistent quality. Links to other websites are provided to website users merely for the sake of convenience. Users access such websites at their own risk. The choice of links should in no way restrict users to the linked pages.</p>

					<p><b>Details supplied by yourself</b></p>
					<p>The user of this website is fully responsible for the content and correctness of details he or she sends to BAYER as well as for the non-violation of any third-party rights that may be involved in such details. The user gives his or her consent for BAYER to store such details and to use the same for the purpose of statistical analysis or for any other specified business purpose, unless the information involves personal details, going beyond master data or usage data as defined in sections 5 and 6 of the German Teleservices Data Protection Act (Teledienstedatenschutzgesetz). In particular, Bayer is entitled to use the contents of such messages, including ideas, inventions, blueprints, techniques and expertise contained therein, for any purpose, such as the development, production and/or marketing of products or services and to reproduce such information and make it available to third parties without any limitations.</p>

					<p><b>Applicable law</b></p>
					<p>Any legal claims or lawsuits in conjunction with this website or its use are subject to the interpretation of the laws of the Federal Republic of Germany, except for the provisions of international private law and the Hague Convention relating to a Uniform Law on the International Sale of Goods of July 1, 1964 and in the UN Sales Convention of April 11, 1980.</p>
				</div>
			</div>
		</div>
	</div>
	<!-- JavaScript -->
	<!--[if lt IE 10]><script src="js/vendor/media.match.min.js"></script><![endif]-->
	<script src="../../js/vendor/jquery.min.js"></script>
	<script src="../../js/vendor/enquire.min.js"></script>
	<script src="../../js/vendor/TweenMax.min.js"></script>
	<script src="../../js/vendor/jquery.mousewheel.pack.js"></script>
	<script src="../../js/vendor/jscrollpane.min.js"></script>
	<script src="../../js/app-lightbox.js"></script>
</body>
</html>